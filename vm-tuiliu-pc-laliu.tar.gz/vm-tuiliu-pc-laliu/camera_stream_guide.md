# ROS2 摄像头推流指南

## 环境说明
- **VM (Linux)**: ROS2 Humble，运行摄像头推流节点
- **PC (Windows)**: 需要安装对应ROS2版本，通过网络拉流

---

## 1. VM端操作步骤

### 1.1 获取VM IP地址
```bash
ip addr show
# 或
hostname -I
```
记录下VM的IP地址，例如：`192.168.1.100`

### 1.2 运行推流节点
```bash
cd ~/camera_ws
source install/setup.bash
ros2 run camera_publisher camera_publisher_node --ros-args -p camera_id:=0 -p width:=640 -p height:=480 -p fps:=30
```

参数说明：
- `camera_id`: 摄像头设备ID，通常0为内置摄像头
- `width/height`: 图像分辨率
- `fps`: 帧率

---

## 2. PC (Windows)端配置

### 2.1 安装ROS2 Humble
从官网下载安装ROS2 Humble for Windows:
https://docs.ros.org/en/humble/Installation/Windows-Install-Binary.html

### 2.2 设置环境变量
以管理员身份打开命令提示符，配置ROS_DISCOVERY以便找到VM的节点：
```cmd
call C:\dev\ros2_humble\local_setup.bat
set ROS_DOMAIN_ID=0
set RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
```

### 2.3 设置VM IP地址（如果自动发现失败）
```cmd
set CYCLONEDDS_URI=file:///C:\path\to\cyclonedds.xml
```

创建 `cyclonedds.xml` 文件内容如下，替换为你的VM IP：
```xml
<CycloneDDS xmlns="https://cdds.io/config" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="https://cdds.io/config https://raw.githubusercontent.com/eclipse-cyclonedds/cyclonedds/master/etc/cyclonedds.xsd">
    <Domain Id="0">
        <General>
            <Interfaces>
                <NetworkInterface name="eth0" auto="true" />
            </Interfaces>
            <Peers>
                <Peer address="YOUR_VM_IP_ADDRESS"/>
            </Peers>
        </General>
    </Domain>
</CycloneDDS>
```

### 2.4 查看和显示图像

**查看话题**:
```cmd
ros2 topic list
# 应该看到 /camera/image_raw
ros2 topic echo /camera/image_raw
```

**显示图像**:
需要安装 `image_view` 包，在Windows编译或使用conda安装后运行：
```cmd
ros2 run image_view image_view --ros-args -r image:=/camera/image_raw
```

或者创建一个简单的订阅节点显示图像。

---

## 3. 验证连接
在VM端可以查看话题：
```bash
source install/setup.bash
ros2 topic hz /camera/image_raw
```
应该能看到稳定的帧率输出。

在PC端应该能看到图像传输并显示出来。
