#include <rclcpp/rclcpp.hpp>
#include <opencv2/opencv.hpp>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <vector>
#include <string>

using namespace std::chrono_literals;

class UDPCameraPublisher : public rclcpp::Node
{
public:
    UDPCameraPublisher() : Node("udp_camera_publisher")
    {
        this->declare_parameter<int>("camera_id", 0);
        this->declare_parameter<int>("width", 640);
        this->declare_parameter<int>("height", 480);
        this->declare_parameter<int>("fps", 30);
        this->declare_parameter<std::string>("dest_ip", "192.168.1.100");
        this->declare_parameter<int>("dest_port", 5000);
        this->declare_parameter<int>("jpeg_quality", 80);

        camera_id_ = this->get_parameter("camera_id").as_int();
        width_ = this->get_parameter("width").as_int();
        height_ = this->get_parameter("height").as_int();
        fps_ = this->get_parameter("fps").as_int();
        dest_ip_ = this->get_parameter("dest_ip").as_string();
        dest_port_ = this->get_parameter("dest_port").as_int();
        jpeg_quality_ = this->get_parameter("jpeg_quality").as_int();

        cap_.open(camera_id_);
        if (!cap_.isOpened()) {
            RCLCPP_ERROR(this->get_logger(), "Failed to open camera with id %d", camera_id_);
            rclcpp::shutdown();
            return;
        }

        cap_.set(cv::CAP_PROP_FRAME_WIDTH, width_);
        cap_.set(cv::CAP_PROP_FRAME_HEIGHT, height_);
        cap_.set(cv::CAP_PROP_FPS, fps_);

        sockfd_ = socket(AF_INET, SOCK_DGRAM, 0);
        if (sockfd_ < 0) {
            RCLCPP_ERROR(this->get_logger(), "Failed to create UDP socket");
            rclcpp::shutdown();
            return;
        }

        memset(&dest_addr_, 0, sizeof(dest_addr_));
        dest_addr_.sin_family = AF_INET;
        dest_addr_.sin_port = htons(dest_port_);
        inet_pton(AF_INET, dest_ip_.c_str(), &dest_addr_.sin_addr);

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(static_cast<int>(1000.0 / fps_)),
            std::bind(&UDPCameraPublisher::publishFrame, this)
        );

        RCLCPP_INFO(this->get_logger(), "UDP Camera publisher started");
        RCLCPP_INFO(this->get_logger(), "Destination: %s:%d", dest_ip_.c_str(), dest_port_);
    }

    ~UDPCameraPublisher()
    {
        if (sockfd_ >= 0) {
            close(sockfd_);
        }
        if (cap_.isOpened()) {
            cap_.release();
        }
    }

private:
    void publishFrame()
    {
        cv::Mat frame;
        cap_ >> frame;

        if (frame.empty()) {
            RCLCPP_WARN(this->get_logger(), "Empty frame captured");
            return;
        }

        std::vector<int> params;
        params.push_back(cv::IMWRITE_JPEG_QUALITY);
        params.push_back(jpeg_quality_);

        std::vector<uchar> buf;
        cv::imencode(".jpg", frame, buf, params);

        int frame_size = buf.size();
        int32_t width_host = htonl(width_);
        int32_t height_host = htonl(height_);
        char header[8];
        memcpy(header, &width_host, 4);
        memcpy(header + 4, &height_host, 4);

        sendto(sockfd_, header, sizeof(header), 0, (struct sockaddr*)&dest_addr_, sizeof(dest_addr_));

        int sent = sendto(sockfd_, buf.data(), frame_size, 0, (struct sockaddr*)&dest_addr_, sizeof(dest_addr_));

        if (sent < 0) {
            RCLCPP_WARN(this->get_logger(), "Failed to send frame");
        }
    }

    cv::VideoCapture cap_;
    int sockfd_;
    struct sockaddr_in dest_addr_;
    rclcpp::TimerBase::SharedPtr timer_;
    int camera_id_;
    int width_;
    int height_;
    int fps_;
    std::string dest_ip_;
    int dest_port_;
    int jpeg_quality_;
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<UDPCameraPublisher>());
    rclcpp::shutdown();
    return 0;
}
