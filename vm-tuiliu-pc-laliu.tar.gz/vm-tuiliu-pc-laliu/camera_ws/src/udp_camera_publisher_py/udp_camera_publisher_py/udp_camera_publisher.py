#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import cv2
import numpy as np
import socket


class UDPCameraPublisher(Node):
    def __init__(self):
        super().__init__('udp_camera_publisher')
        
        # 声明参数
        self.declare_parameter('camera_id', 0)
        self.declare_parameter('width', 640)
        self.declare_parameter('height', 480)
        self.declare_parameter('fps', 30)
        self.declare_parameter('dest_ip', '192.168.1.100')
        self.declare_parameter('dest_port', 5000)
        self.declare_parameter('jpeg_quality', 80)
        
        # 获取参数
        self.camera_id = self.get_parameter('camera_id').value
        self.width = self.get_parameter('width').value
        self.height = self.get_parameter('height').value
        self.fps = self.get_parameter('fps').value
        self.dest_ip = self.get_parameter('dest_ip').value
        self.dest_port = self.get_parameter('dest_port').value
        self.jpeg_quality = self.get_parameter('jpeg_quality').value
        
        # 打开摄像头
        self.cap = cv2.VideoCapture(self.camera_id)
        if not self.cap.isOpened():
            self.get_logger().error(f'Failed to open camera with id {self.camera_id}')
            rclpy.shutdown()
            return
        
        # 设置摄像头参数
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        self.cap.set(cv2.CAP_PROP_FPS, self.fps)
        
        # 创建UDP socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        # 创建定时器
        timer_period = 1.0 / self.fps
        self.timer = self.create_timer(timer_period, self.publish_frame)
        
        self.get_logger().info('UDP Camera publisher started')
        self.get_logger().info(f'Destination: {self.dest_ip}:{self.dest_port}')
    
    def publish_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn('Empty frame captured')
            return
        
        # JPEG压缩
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), self.jpeg_quality]
        result, encimg = cv2.imencode('.jpg', frame, encode_param)
        
        if not result:
            self.get_logger().warn('Failed to encode frame to JPEG')
            return
        
        # 发送包头 width和height 用网络字节序(大端)
        header = self.width.to_bytes(4, byteorder='big') + self.height.to_bytes(4, byteorder='big')
        self.sock.sendto(header, (self.dest_ip, self.dest_port))
        
        # 发送图像数据
        self.sock.sendto(encimg.tobytes(), (self.dest_ip, self.dest_port))
    
    def destroy_node(self):
        if self.cap.isOpened():
            self.cap.release()
        self.sock.close()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = UDPCameraPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
