/*
 * PC端UDP摄像头接收显示代码
 * 编译需要: OpenCV
 * Windows编译命令 (使用MSVC):
 *   cl pc_udp_receiver.cpp /I C:\opencv\build\include /link C:\opencv\build\x64\vc15\lib\opencv_world4xx.lib
 * 或者使用MinGW:
 *   g++ pc_udp_receiver.cpp -o pc_udp_receiver.exe -lopencv_core4xx -lopencv_highgui4xx -lopencv_imgcodecs4xx -lws2_32
 */

#include <iostream>
#include <winsock2.h>
#include <opencv2/opencv.hpp>

#pragma comment(lib, "ws2_32.lib")

#define BUFFER_SIZE 65535

int main(int argc, char* argv[])
{
    int port = 5000;
    if (argc > 1) {
        port = atoi(argv[1]);
    }

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed" << std::endl;
        return -1;
    }

    SOCKET sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == INVALID_SOCKET) {
        std::cerr << "Failed to create socket" << std::endl;
        WSACleanup();
        return -1;
    }

    sockaddr_in serverAddr;
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(port);

    if (bind(sockfd, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        std::cerr << "Bind failed on port " << port << std::endl;
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }

    std::cout << "UDP Receiver started on port " << port << std::endl;
    std::cout << "Waiting for camera stream..." << std::endl;

    cv::namedWindow("Camera Stream", cv::WINDOW_NORMAL);

    char buffer[BUFFER_SIZE];
    int width, height;

    while (true) {
        sockaddr_in clientAddr;
        int clientLen = sizeof(clientAddr);

        int headerSize = recvfrom(sockfd, buffer, sizeof(int)*2, 0, (sockaddr*)&clientAddr, &clientLen);
        if (headerSize == sizeof(int)*2) {
            memcpy(&width, buffer, sizeof(int));
            memcpy(&height, buffer + sizeof(int), sizeof(int));
        }

        int imageSize = recvfrom(sockfd, buffer, BUFFER_SIZE, 0, (sockaddr*)&clientAddr, &clientLen);
        if (imageSize > 0) {
            std::vector<uchar> imgBuffer(buffer, buffer + imageSize);
            cv::Mat frame = cv::imdecode(imgBuffer, cv::IMREAD_COLOR);
            if (!frame.empty()) {
                cv::imshow("Camera Stream", frame);
                if (cv::waitKey(1) == 27) {
                    break;
                }
            }
        }
    }

    closesocket(sockfd);
    WSACleanup();
    cv::destroyAllWindows();

    return 0;
}
