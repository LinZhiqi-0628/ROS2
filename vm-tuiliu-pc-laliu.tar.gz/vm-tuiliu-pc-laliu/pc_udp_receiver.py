#!/usr/bin/env python3
"""
PC端UDP摄像头接收显示 Python版本
依赖: pip install opencv-python
运行: python pc_udp_receiver.py [port]
"""

import socket
import cv2
import numpy as np
import sys

BUFFER_SIZE = 65535

def main(port=5000):
    # 创建UDP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('0.0.0.0', port))
    
    print(f"UDP Receiver started on port {port}")
    print("Waiting for camera stream... (Press ESC to exit)")
    
    cv2.namedWindow("Camera Stream", cv2.WINDOW_NORMAL)
    
    while True:
        # 接收包头 (width and height)
        header_data, _ = sock.recvfrom(8)
        if len(header_data) == 8:
            # C++发送的是网络字节序(大端)
            width = int.from_bytes(header_data[0:4], byteorder='big')
            height = int.from_bytes(header_data[4:8], byteorder='big')
        
        # 接收图像数据
        img_data, _ = sock.recvfrom(BUFFER_SIZE)
        if len(img_data) > 0:
            # 解码JPEG
            nparr = np.frombuffer(img_data, np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if frame is not None:
                cv2.imshow("Camera Stream", frame)
                # 按ESC退出
                if cv2.waitKey(1) == 27:
                    break
    
    cv2.destroyAllWindows()
    sock.close()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        port = int(sys.argv[1])
        main(port)
    else:
        main()
