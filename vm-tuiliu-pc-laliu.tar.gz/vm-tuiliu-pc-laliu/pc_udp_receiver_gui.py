#!/usr/bin/env python3
"""
PC端UDP摄像头接收显示 - PyQt6 GUI版本
依赖: pip install pyqt6 opencv-python numpy
运行: python pc_udp_receiver_gui.py
"""

import sys
import socket
import numpy as np
import cv2
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSpinBox, QLineEdit, QGroupBox
)
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtCore import QThread, pyqtSignal, Qt


class StreamReceiverThread(QThread):
    frame_ready = pyqtSignal(np.ndarray)
    
    def __init__(self, ip='0.0.0.0', port=5000):
        super().__init__()
        self.ip = ip
        self.port = port
        self.running = False
        self.sock = None
        
    def run(self):
        self.running = True
        BUFFER_SIZE = 65535
        
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.bind((self.ip, self.port))
            
            while self.running:
                # 接收包头
                header_data, _ = self.sock.recvfrom(8)
                if len(header_data) == 8:
                    width = int.from_bytes(header_data[0:4], byteorder='big')
                    height = int.from_bytes(header_data[4:8], byteorder='big')
                
                # 接收图像数据
                img_data, _ = self.sock.recvfrom(BUFFER_SIZE)
                if len(img_data) > 0 and self.running:
                    nparr = np.frombuffer(img_data, np.uint8)
                    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    if frame is not None:
                        self.frame_ready.emit(frame)
        except Exception as e:
            print(f"Receiver error: {e}")
        finally:
            if self.sock:
                self.sock.close()
    
    def stop(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except:
                pass
        self.wait()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("UDP Camera Stream Receiver")
        self.setGeometry(100, 100, 800, 600)
        
        self.receiver_thread = None
        self.init_ui()
    
    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout()
        
        # 配置区域
        config_group = QGroupBox("配置")
        config_layout = QHBoxLayout()
        
        config_layout.addWidget(QLabel("监听端口:"))
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1000, 65535)
        self.port_spin.setValue(5000)
        config_layout.addWidget(self.port_spin)
        
        config_layout.addStretch()
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # 视频显示区域
        self.video_label = QLabel()
        self.video_label.setMinimumSize(640, 480)
        self.video_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.video_label.setText("等待开始拉流...")
        layout.addWidget(self.video_label)
        
        # 按钮区域
        btn_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("开始拉流")
        self.start_btn.clicked.connect(self.start_stream)
        btn_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("停止拉流")
        self.stop_btn.clicked.connect(self.stop_stream)
        self.stop_btn.setEnabled(False)
        btn_layout.addWidget(self.stop_btn)
        
        self.close_btn = QPushButton("关闭程序")
        self.close_btn.clicked.connect(self.close)
        btn_layout.addWidget(self.close_btn)
        
        layout.addLayout(btn_layout)
        central_widget.setLayout(layout)
    
    def start_stream(self):
        port = self.port_spin.value()
        self.receiver_thread = StreamReceiverThread(port=port)
        self.receiver_thread.frame_ready.connect(self.update_frame)
        self.receiver_thread.start()
        
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.port_spin.setEnabled(False)
    
    def stop_stream(self):
        if self.receiver_thread:
            self.receiver_thread.stop()
            self.receiver_thread = None
        
        self.video_label.setText("等待开始拉流...")
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.port_spin.setEnabled(True)
    
    def update_frame(self, frame):
        # BGR to RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pixmap = QPixmap.fromImage(q_img)
        
        # 缩放适应窗口
        scaled_pixmap = pixmap.scaled(
            self.video_label.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.video_label.setPixmap(scaled_pixmap)
    
    def closeEvent(self, event):
        self.stop_stream()
        event.accept()


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
