=== UDP 摄像头推流 (VM/Jetson) + 拉流 (PC) ===

===== 架构说明
- VM/Jetson (Linux ROS2): 采集摄像头，压缩JPEG，通过UDP发送到PC，全Python实现
- PC (Windows): 接收UDP数据包，解码显示，无需安装ROS2！Python + PyQt6 GUI

===== VM/Jetson端 (Linux ROS2 Python) 运行步骤

1. 进入工作空间
cd /home/z/vm-tuiliu-pc-laliu/camera_ws

2. 配置环境
source install/setup.bash

3. 安装依赖
pip install opencv-python numpy

4. 运行推流节点
替换 192.168.1.100 为你的PC的IP地址:
ros2 run udp_camera_publisher_py udp_camera_publisher --ros-args \
  -p camera_id:=0 \
  -p width:=640 \
  -p height:=480 \
  -p fps:=30 \
  -p dest_ip:="192.168.1.100" \
  -p dest_port:=5000 \
  -p jpeg_quality:=80

参数说明:
- camera_id: 摄像头设备ID，默认0
- width: 图像宽度，默认640
- height: 图像高度，默认480
- fps: 帧率，默认30
- dest_ip: PC的IP地址，必须修改为你实际的PC IP
- dest_port: UDP发送端口，默认5000
- jpeg_quality: JPEG压缩质量 0-100，默认80

===== PC端 (Windows / Python PyQt6 GUI版本 - 推荐!)

1. 前置要求
- 安装Python
- 安装依赖: pip install pyqt6 opencv-python numpy

2. 运行
将 pc_udp_receiver_gui.py 复制到PC, 直接运行:
python pc_udp_receiver_gui.py

界面功能:
- 可以设置监听端口 (默认5000)
- 点击 "开始拉流" 按钮开始接收视频
- 点击 "停止拉流" 按钮停止接收
- 点击 "关闭程序" 退出程序
- 视频画面会自动缩放适应窗口

===== PC端 (Windows / Python 命令行版本)

1. 前置要求
- 安装Python
- 安装依赖: pip install opencv-python numpy

2. 运行
将 pc_udp_receiver.py 复制到PC, 直接运行:
python pc_udp_receiver.py [port]
默认端口 5000:
python pc_udp_receiver.py

窗口会打开显示摄像头画面，按ESC退出。

===== PC端 (C++ 可选) 使用步骤

1. 前置要求
- 安装OpenCV开发环境 (MSVC或MinGW都可以)
- 将代码 pc_udp_receiver.cpp 复制到PC

2. 编译代码 (两种方式:

方式1: 使用MSVC Visual Studio命令行:
cl pc_udp_receiver.cpp /I C:\opencv\build\include /link C:\opencv\build\x64\vc15\lib\opencv_world4xx.lib
注意修改路径和版本号 (将4xx替换为你的OpenCV版本，比如455表示4.5.5)

方式2: 使用MinGW:
g++ pc_udp_receiver.cpp -o pc_udp_receiver.exe -lopencv_core4xx -lopencv_highgui4xx -lopencv_imgcodecs4xx -lws2_32

3. 运行接收程序
pc_udp_receiver.exe 5000

窗口会打开并显示摄像头画面，按ESC退出。

===== 网络配置说明

1. 确保发送端和PC在同一局域网内，可以互相ping通

2. 检查PC防火墙，开放5000 UDP端口

3. 如果是桥接网络，直接使用PC实际IP即可
   如果是NAT网络，需要配置端口转发

协议: UDP 5000 -> 5000

===== 协议格式:
先发送8字节包头: [width (int 网络字节序大端) + height (int 网络字节序大端)]
然后发送JPEG压缩图像数据

===== 文件位置
- VM/Jetson推流代码(Python): /home/z/vm-tuiliu-pc-laliu/camera_ws/src/udp_camera_publisher_py/udp_camera_publisher_py/udp_camera_publisher.py
- PC GUI接收代码(PyQt6): /home/z/vm-tuiliu-pc-laliu/pc_udp_receiver_gui.py
- PC命令行接收代码(Python): /home/z/vm-tuiliu-pc-laliu/pc_udp_receiver.py
- PC C++接收代码(可选): /home/z/vm-tuiliu-pc-laliu/pc_udp_receiver.cpp
